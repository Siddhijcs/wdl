<?php $__env->startComponent('mail::message'); ?>
# Welcome to freeCodeGram

This is a community of fellow developers and we love that you have joined us.


All the best,<br>
Victor
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\laravel\resources\views/emails/welcome-email.blade.php ENDPATH**/ ?>